Good Search:

---REQUIREMENTS
No requirements, both lucene libraries, both external libraries, are linked in jar file, so it is completely stand alone


---HOW TO USE
This file should be contained in the main directory on the project, with resources directories (benchmark, doc, media, ...) and jar file of the project.
JAR file (GoodSearch.jar) is executable via gui or giving command
	java -jar GoodSearch.jar 
in command line.
Reference to "HELP" button in GUI to get advises on query formulation.

---DOCUMENTATION
Documentation is available in "doc" folder, readable opening index.html file using an internet browser

---BENCHMARK 
Using benchmark button in GUI will start a benchmark test on GoodSearch, using selected IR Model. This will produce some plot files, contained under benchmark/lisa/Results

