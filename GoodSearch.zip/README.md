# GAvI-Project

## This is the project for the exam of Advanced Management of the Information (GAvI in italian)

# Structure 

#### doc: a place for documentation files

#### media: where all media files (logo, screenshots, ...) are stored

#### src: where source files are be stored

#### other: this folder is intended to contain all that not fit other categories (generically, some text files for debug)

N.B.: all of the above folders/categories could contain sub-folders/sub-categories (for example packages to split java source files)
